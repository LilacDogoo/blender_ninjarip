"""
Author: LilacDogoo
"""